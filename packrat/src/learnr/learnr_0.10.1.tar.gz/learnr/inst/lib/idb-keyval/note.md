[Original File Location](https://github.com/jakearchibald/idb-keyval/blob/master/dist/idb-keyval-iife-compat.min.js)
[New File Location](https://github.com/schloerke/idb-keyval/blob/idb-keyval/dist/idb-keyval-iife-compat.min.js)
[PR](https://github.com/jakearchibald/idb-keyval/pull/73)
