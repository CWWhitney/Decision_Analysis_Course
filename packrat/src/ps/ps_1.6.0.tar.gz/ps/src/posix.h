
int ps__pid_exists(long pid);
void ps__raise_for_pid(long pid, char *msg);
