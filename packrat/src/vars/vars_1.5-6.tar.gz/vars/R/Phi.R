"Phi" <-
function(x, nstep=10, ...){
  UseMethod("Phi", x)
}
