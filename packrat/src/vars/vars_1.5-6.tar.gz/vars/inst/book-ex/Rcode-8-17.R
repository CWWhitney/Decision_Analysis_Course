fevd.U <- fevd(svec, n.ahead = 48)$U
