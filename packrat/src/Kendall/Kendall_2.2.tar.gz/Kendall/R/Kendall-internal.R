".onLoad" <-
function(lib, pkg) library.dynam("Kendall", pkg, lib)

