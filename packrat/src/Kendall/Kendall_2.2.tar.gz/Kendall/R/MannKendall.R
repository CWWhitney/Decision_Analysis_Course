"MannKendall" <-
function(x)
{
	Kendall(1.:length(x), x)
}

