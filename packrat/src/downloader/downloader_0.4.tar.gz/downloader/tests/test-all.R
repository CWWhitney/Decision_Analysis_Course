library(testthat)
library(downloader)

test_package("downloader")
