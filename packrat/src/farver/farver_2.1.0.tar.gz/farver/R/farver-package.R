#' @useDynLib farver
#' @keywords internal
'_PACKAGE'