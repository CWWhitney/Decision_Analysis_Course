# drive_auth_configure works

    Code
      drive_auth_configure(app = gargle::gargle_app(), path = "PATH")
    Error <rlang_error>
      Must supply exactly one of `app` or `path`, not both

