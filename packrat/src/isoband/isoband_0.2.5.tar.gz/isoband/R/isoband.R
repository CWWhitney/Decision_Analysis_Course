#' @useDynLib isoband, .registration = TRUE
#' @importFrom utils modifyList
#' @import grid
"_PACKAGE"
