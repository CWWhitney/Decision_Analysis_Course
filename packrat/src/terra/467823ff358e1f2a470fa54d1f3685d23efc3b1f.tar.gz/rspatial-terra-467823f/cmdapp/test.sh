./terra show ../inst/ex/test.tif
./terra aggregate ../inst/ex/test.tif  "" 10 mean 1
