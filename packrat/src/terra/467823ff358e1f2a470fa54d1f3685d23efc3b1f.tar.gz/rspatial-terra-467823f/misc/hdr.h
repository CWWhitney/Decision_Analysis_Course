std::vector<std::string> hdr_read(std::string filename);
bool hdr_write(std::vector<std::string> s);
