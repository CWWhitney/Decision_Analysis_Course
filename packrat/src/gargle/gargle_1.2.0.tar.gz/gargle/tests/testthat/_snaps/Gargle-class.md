# Gargle2.0 prints nicely

    Code
      print(fauxen)
    Output
      
      -- <Token (via gargle)> --------------------------------------------------------
      oauth_endpoint: google
                 app: APPNAME
               email: 'a@example.org'
              scopes: ...userinfo.email
         credentials: a

