# request_develop() errors for unrecognized parameters

    These parameters are unknown:
    * 'b'
    * 'c'

# request_develop() errors if required parameter is missing

    These parameters are missing:
    * 'a'

