# AuthState prints nicely

    Code
      print(a)
    Output
      
      -- <AuthState (via gargle)> ----------------------------------------------------
          package: PKG
              app: APPNAME
          api_key: API_KEY
      auth_active: TRUE
      credentials: <some_sort_of_token>

