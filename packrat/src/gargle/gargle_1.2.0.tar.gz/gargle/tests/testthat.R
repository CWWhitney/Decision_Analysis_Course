library(testthat)
library(gargle)

test_check("gargle")
