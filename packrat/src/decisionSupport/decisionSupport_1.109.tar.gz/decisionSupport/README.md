
<!-- README.md is generated from README.Rmd. Please edit that file -->

[<img src="https://raw.githubusercontent.com/eikeluedeling/decisionSupport/master/vignettes/decisionSupport.png" align="right" height="120"/>](https://CRAN.R-project.org/package=decisionSupport)

<!-- badges: start -->

[![CRAN
Status](http://www.r-pkg.org/badges/version/decisionSupport?color=yellow)](https://cran.r-project.org/package=decisionSupport)
[![](http://cranlogs.r-pkg.org/badges/grand-total/decisionSupport?color=orange)](https://cran.r-project.org/package=decisionSupport)
[![](http://cranlogs.r-pkg.org/badges/decisionSupport?color=blue)](https://cran.r-project.org/package=decisionSupport)
[![](http://cranlogs.r-pkg.org/badges/last-week/decisionSupport?color=green)](https://cran.r-project.org/package=decisionSupport)
<!-- badges: end -->

# decisionSupport

The R-package decisionSupport is free software: you can redistribute it
and/or modify it under the terms of the GNU General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.

The R-package decisionSupport is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along
with the R-package decisionSupport. If not, see
<a href="http://www.gnu.org/licenses/" class="uri">http://www.gnu.org/licenses/</a>.

<!-- Links: start -->

| Quick Links                                                            |
|:-----------------------------------------------------------------------|
| [**CRAN Version**](https://cran.r-project.org/package=decisionSupport) |

<!-- Links: end -->

## Installation

Install the released version of decisionSupport from
[CRAN](https://CRAN.R-project.org) with
`install.packages("decisionSupport")`.

## References

…
