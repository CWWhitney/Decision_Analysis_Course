utils::globalVariables(c('x_scale', 'value', 'p5', 
                         'p95', 'p75', 'p50', 'p25', 
                         'name', 'decision_option', 'label', 'Coefficient', 
                         'output_variable', 'EVPI'))
