library(testthat)
library(dtplyr)

test_check("dtplyr")
