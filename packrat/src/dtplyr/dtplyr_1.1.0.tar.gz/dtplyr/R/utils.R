cat_line <- function(...) cat(paste(..., "\n", collapse = "", sep = ""))
