.onAttach <- function(libname, pkgname) {
  packageStartupMessage("fANCOVA 0.6-1 loaded")
}
