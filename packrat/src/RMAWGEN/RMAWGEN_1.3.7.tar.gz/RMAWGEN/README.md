RMAWGEN
=======

Github version on RMAWGEN package (http://cran.r-project.org/web/packages/RMAWGEN/index.html)

# Installation notes from R Console: 


library(devtools)

install_github("ecor/RMAWGEN")



