#ifndef CHECKMATE_FIND_MIN_NCHAR_H_
#define CHECKMATE_FIND_MIN_NCHAR_H_

#include <R.h>
#include <Rinternals.h>

R_xlen_t find_min_nchar(SEXP, R_xlen_t, Rboolean);

#endif
