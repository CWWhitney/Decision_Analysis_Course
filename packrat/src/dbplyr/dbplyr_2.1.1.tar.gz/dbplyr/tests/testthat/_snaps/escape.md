# shiny objects give useful errors

    Cannot translate shiny inputs to SQL.
    * Force evaluation in R with (e.g.) `!!inputs$x` or `local(inputs$x)`

---

    Cannot translate a shiny reactive to SQL.
    * Force evaluation in R with (e.g.) `!!foo()` or `local(foo())`

