#ifndef GHQ_H
#define GHQ_H

void F77_NAME(ghq)(int *n, double *x, double *w, int *modified);

#endif
