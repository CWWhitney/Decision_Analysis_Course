setClass("CURLAuth", contains = "BitwiseValue")
