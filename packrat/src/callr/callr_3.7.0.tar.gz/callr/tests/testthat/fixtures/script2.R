cat("out1")
message("err1", appendLF = FALSE)
cat("out2")
message("err2")
