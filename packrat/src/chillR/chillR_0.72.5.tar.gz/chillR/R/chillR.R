utils::globalVariables(c("california_stations"))
