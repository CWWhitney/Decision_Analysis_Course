/* Header file for prefix_sums.c */

#ifndef _UTILS_H
#define _UTILS_H
#include "graph_defs.h"

void prefix_sums(attr_id_t*, attr_id_t*, attr_id_t*, attr_id_t);

#endif
