/* Header file for process_sparse.c */

#include <R.h>

#ifndef PROCESS_SPARSE_H
#define PROCESS_SPARSE_H

SEXP process_sparse_R(SEXP sI, SEXP sJ, SEXP sX, SEXP sAi, SEXP sdeg, SEXP sn)

#endif
