
quos_list <- function(...) {
  new_quosures(list(...))
}
