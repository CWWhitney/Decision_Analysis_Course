\dontrun{
  palette_pander(TRUE)
}
